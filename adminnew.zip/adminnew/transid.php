<?php
ob_start();
?>
<?php
require('connection.inc.php');
require('functions.inc.php');

$codtotal='';
$msg='';
if(isset($_GET['id']) && $_GET['id']!=''){
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from codtotal where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$transid=$row['transid'];
	}else{
		header('location: orders.php');
		ob_enf_fluch();
		die();
	}
}

if(isset($_POST['submit'])){
	$transid=get_safe_value($con,$_POST['transid']);
	$res=mysqli_query($con,"select * from codtotal where transid='$transid'");
	$check=mysqli_num_rows($res);
	if($check>0){
		if(isset($_GET['id']) && $_GET['id']!=''){
			$getData=mysqli_fetch_assoc($res);
			if($id==$getData['id']){
			
			}else{
				$msg="Transaction ID already exist";
			}
		}else{
			$msg="Transaction ID already exist";
		}
	}
	
	if($msg==''){
		if(isset($_GET['id']) && $_GET['id']!=''){
			mysqli_query($con,"update codtotal set transid='$transid' where id='$id'");
		}else{
			mysqli_query($con,"insert into codtotal(transid,status1) values('$transid','1')");
		}
		header('location: orders.php');
		ob_enf_fluch();
		die();
	}
}
?>

<?php 

       if(!empty($_SESSION["username"])){ 
        
?>


<?php include 'includes/headers.php';?>

    <div id="wrapper">

      <!-- Sidebar -->
      <?php include 'includes/sidebar.php' ?>


 <div class="card-body">
   <div class="table-responsive">
   	<form method="post">
    <div class="form-group">
			<label for="orders" class="form-control-label">Transaction ID</label>
			<input type="text" name="transid" class="form-control" required value="<?php echo $transid;?>">	
	</div>
	<button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
		<span id="payment-button-amount">Submit</span>
	</button>
	<div class="field_error"><?php echo $msg?></div>
</form>
</div>
</div>

<?php
        } else {

?>
<?php header('location:login.php'); ?>
<?php } ?>