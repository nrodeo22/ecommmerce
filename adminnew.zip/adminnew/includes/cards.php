 <?php
// include functions and connect to the database using PDO MySQL
include 'includes/functions.php';
$pdo = pdo_connect_mysql();

  include 'includes/ddb.php';

// select products and users
$stmt = $db->prepare('SELECT * FROM products');
$stmt = $db->prepare('SELECT * FROM users');
$stmt = $db->query('SELECT * FROM codtotal');
$res1 = $db->prepare('SELECT SUM(totalpayment) AS total_sale FROM codtotal');
$res1->execute();
$saletot = 0;
while($row1 = $res1->fetch(PDO::FETCH_ASSOC)) {
$saletot += $row1['total_sale'];
}
// fetch the products and users from the database and return the result as an Array
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
// get the total number of products and users
$total_products = $db->query('SELECT * FROM products')->rowCount();
$total_user = $db->query('SELECT * FROM users')->rowCount();
$total_orders = $db->query('SELECT * FROM codtotal')->rowCount();
?>

 <div class="row">
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-primary o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-comments"></i>
                  </div>
                  <div class="mr-5"><?=$total_products?></div>
                  <span>Products</span>
                </div>
                
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-warning o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-list"></i>
                  </div>
                  <div class="mr-5"><?=$total_orders?></div>
                  <span>Orders</span>
                </div>
                
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-success o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-shopping-cart"></i>
                  </div>
                  <div class="mr-5"><?=$total_user?></div>
                  <span>Users</span>
                </div>
                
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-danger o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-fw fa-life-ring"></i>
                  </div>
                  <div class="mr-5"><?=$saletot?></div>
                  <span>Sales</span>
                </div>
                
              </div>
            </div>
          </div>