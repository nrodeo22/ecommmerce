<?php
    require_once 'connection.inc.php';

    if(isset($_SESSION['id'])){
    
        $username = $_POST["username"];
        
        }else{
            header('location:../index.php');
        }