
<?php
	include 'includes/ddb.php';
	
	if(!isset($_SESSION['username']) || trim($_SESSION['username']) == 'admin'){

		header('location: index.php');
		exit();


	}
	$conn = $pdo->open();

	$stmt = $conn->prepare("SELECT * FROM admin_users WHERE id='' ");
	$stmt->execute(['username'=>$_SESSION['admin']]);
	$admin = $stmt->fetch();

	$pdo->close();
	

?>
