
<ul class="sidebar navbar-nav">

        <li class="nav-item active">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="manage_user.php">
            <i class="fas fa-fw fa-folder"></i>
            <span>Manage User</span>
          </a>

        </li>
        <li class="nav-item">
          <a class="nav-link" href="category.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Manage Category</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="product.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Manage Product</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="orders.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Orders</span></a>
        </li>
      </ul>