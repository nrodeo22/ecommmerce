<?php
  session_start();
?>
<?php include 'includes/headers.php' ?>

<?php 

if(!empty($_SESSION["username"]) && $_SESSION["username"]=="admin"){ 
        
?>

    <div id="wrapper">

      <!-- Sidebar -->
     <?php include 'includes/sidebar.php' ?> 

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>

          <!-- Icon Cards-->
         <?php include 'includes/cards.php' ?> 

          <!-- Area Chart Example-->

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <?php include 'includes/footer.php' ?>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    
  <?php include 'includes/logout_modal.php' ?>

    <?php include 'js/js.php' ?>

<?php
        } else {

?>
<?php header('location:../home.php'); ?>
<?php } ?>

  </body>

</html>

