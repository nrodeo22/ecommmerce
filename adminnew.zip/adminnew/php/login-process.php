<?php
	session_start();
	$host 		= "localhost";
	$username 	= "id16475034_adminnew";
	$password 	= "-r?Hz6$5Z&+><9}9";
	$database 	= "id16475034_adminpanel";

	try{
		$connect = new PDO("mysql:host=$host;dbname=$database", $username, $password);
		$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		if(isset($_POST["signin-button"])){
			$username = $_POST['username'];
			$password = hash('sha256',$_POST['password']);
			// $password = $_POST['password'];

			/*if($username == 'admin'){
				$_SESSION["username"] = $username;
				header("Location:../index.php");
			}*/
	
			if(empty($username) || empty($password)){
				header("Location:../login.php?error=emptyFields");
				exit();
			} else {
				$query = "SELECT * FROM admin_users WHERE username = :username AND password = :password";
				$statement = $connect->prepare($query);
				$statement->execute(
					array(
						'username' => $username,
						'password' => $password
					)
				);

				$count = $statement->rowCount();
				
			/*	$query2 = "SELECT * FROM users WHERE username = :username AND password = :password";
				$statement2 = $connect->prepare($query2);
				$statement2->execute(
					array(
						'username' => $username,
						'password' => $password
					)
				);

				
				$count2 = $statement2->rowCount(); */

				if($count > 0 && $username == 'admin'){
					$_SESSION["username"] = $username;
					header("Location:../index.php");
					echo 'hit';

				} 
			
				else {
					header("Location:../login.php?error=invalidUsernameOrPassword");
				}
			}
		}
	}
	catch(PDOException $error){
		$message = $error->getMessage();
	}
?>
