
<?php
  require('connection.inc.php');
  require('functions.inc.php');

if(isset($_GET['type']) && $_GET['type']!=''){
  $type=get_safe_value($con,$_GET['type']);
  if($type=='status'){
    $operation=get_safe_value($con,$_GET['operation']);
    $id=get_safe_value($con,$_GET['id']);
    if($operation=='active'){
      $status='On Delivery';
    }else{
      $status='Canceled';
    }
    $update_status_sql="update codtotal set status='$status' where id='$id'";
    mysqli_query($con,$update_status_sql);
  }
  if($type=='status1'){
    $operation=get_safe_value($con,$_GET['operation']);
    $id=get_safe_value($con,$_GET['id']);
    if($operation=='active'){
      $status1='1';
    }else{
      $status1='0';
    }
    $update_status1_sql="update codtotal set status1='$status1' where id='$id'";
    mysqli_query($con,$update_status1_sql);
  }
  if($type=='delete'){
    $id=get_safe_value($con,$_GET['id']);
    $delete_sql="delete from codtotal where id='$id'";
    mysqli_query($con,$delete_sql);
  }
}

?>

<?php 

       if(!empty($_SESSION["username"])){ 
        
?>


<?php include 'includes/headers.php';?>

    <div id="wrapper">

      <!-- Sidebar -->
      <?php include 'includes/sidebar.php' ?>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Products</li>
          </ol>

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Data Table Example</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Transid</th>
                       <th>Fullname</th>
                       <th>Phonenumber</th>
                       <th>Address</th>
                       <th>Items</th>
                       <th>Shipping Time</th>
                       <th>Total Payment</th>
                       <th>Status</th>
                       <th></th>

                    </tr>
                  </thead>
                    <?php 
                      $query = "SELECT * FROM codtotal";
                      $result = $con->query($query);
                      if ($result->num_rows > 0) {
                        while ($rows = $result->fetch_assoc()) {
                          $id = $rows['id'];
                          $transid = $rows['transid'];
                          $fullname = $rows['fullname'];
                          $phonenumber = $rows['phonenumber'];
                          $address = $rows['address'];
                          
                          $item = $rows['item'];
                          $shippingoption = $rows['shippingoption'];
                         
                          $totalpayment = $rows['totalpayment'];
                          
                          $status = $rows['status'];
                    ?>
                  <tbody>
                    
                      <tr>
                        <td><?php 
                            echo $transid;
                            echo "<br><span class='badge badge-edit'><a href='transid.php?id=".$id."'>Edit</a></span>&nbsp;";
                            ?>                        
                        </td>
                         <td><?php echo $fullname;?></td>
                         <td><?php echo $phonenumber;?></td>
                         <td><?php echo $address;?></td>
                    
                         <td><?php echo $item;?></td>
                         <td><?php echo $shippingoption;?></td>           
                     
                         <td>&#8369;<?php echo $totalpayment;?></td>
                        
                         <td>
                          <?php 
                          if ($status == 'On Delivery') {
                            echo "<a href = '?type=status&operation=deactive&id=".$id."'>On Delivery</a>";
                          }
                          else{
                            echo "<a href = '?type=status&operation=active&id=".$id."'>Cancel</a>";
                          }
                          ?>
                          <td>
                            <?php
                            echo "<span class='badge badge-delete'><a href='?type=delete&id=".$id."'>Delete</a></span>";
                            ?>
                          </td>
                         </td>
                      </tr>
                      
                  </tbody>
                  <?php }} ?> 
                </table>
              </div>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>

          <p class="small text-center text-muted my-5">
            <em>More table examples coming soon...</em>
          </p>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <?php include 'includes/footer.php' ?>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <?php include 'includes/logout_modal.php' ?>

    <?php include 'js/js.php' ?>


<?php
        } else {

?>
<?php header('location:login.php'); ?>
<?php } ?>
  </body>

</html>
