<?php
ob_start()
?>

<?php
require('connection.inc.php');
require('functions.inc.php');

$categories_id = '';
$name = '';
$description = '';
$price = '';
$rrp = '';
$qty = '';
$prokey = '';
$image = '';
$msg = '';

$image_required='required';
if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from products where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$categories_id=$row['categories_id'];
		$name=$row['name'];
		$description=$row['description'];
		$rrp=$row['rrp'];
		$price=$row['price'];
		$qty=$row['qty'];
		$prokey=$row['prokey'];

	}else{
		header('location:product.php');
		ob_enf_fluch();
		die();
	}
}

if(isset($_POST['submit'])){
	$categories_id=get_safe_value($con,$_POST['categories_id']);
	$name=get_safe_value($con,$_POST['name']);
	$description=get_safe_value($con,$_POST['description']);
	$rrp=get_safe_value($con,$_POST['rrp']);
	$price=get_safe_value($con,$_POST['price']);
	$qty=get_safe_value($con,$_POST['qty']);
	$prokey=get_safe_value($con,$_POST['prokey']);	
	$res=mysqli_query($con,"select * from products where name='$name'");
	$check=mysqli_num_rows($res);
	if($check>0){
		if(isset($_GET['id']) && $_GET['id']!=''){
			$getData=mysqli_fetch_assoc($res);
			if($id==$getData['id']){
			
			}else{
				$msg="Product already exist";
			}
		}else{
			$msg="Product already exist";
		}
	}
	
	
	if($msg==''){
		if(isset($_GET['id']) && $_GET['id']!=''){
			if($_FILES['image']['name']!=''){
				$image=$_FILES['image']['name'];
				//move_uploaded_file($_FILES['image']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);
				$update_sql="update products set categories_id='$categories_id',name='$name',description='$description',price='$price',rrp='$rrp',qty='$qty',prokey='$prokey',image='$image' where id='$id'";
			}else{
				$update_sql="update products set categories_id='$categories_id',name='$name',description='$description',price='$price',rrp='$rrp',qty='$qty',prokey='$prokey', where id='$id'";
			}
			mysqli_query($con,$update_sql);
		}else{
			$image=$_FILES['image']['name'];
			//move_uploaded_file($_FILES['image']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);
			mysqli_query($con,"insert into products(categories_id,name,description,price,rrp,qty,prokey,status,image) values('$categories_id','$name','$description','$price','$rrp','$qty','$prokey',1	,'$image')");
		}
		header('location: product.php');
		die();
	}
}
?>

<head>
	
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<style type="text/css">
	
.red{
    color:red;
    }
.form-area
{
    background-color: #FAFAFA;
	padding: 10px 40px 60px;
	margin: 10px 0px 60px;
	border: 1px solid GREY;
}
.container{
	padding-left: 10rem;
}

</style>

</head>

<?php 

       if(!empty($_SESSION["username"])){ 
        
?>



<?php include 'includes/headers.php';?>

<div id="wrapper">

      <!-- Sidebar -->
      <?php include 'includes/sidebar.php' ?>

	

 <div class="card-body">
   <div class="table-responsive">
    <div class="form-area">  
        <form role="form" method="post" enctype="multipart/form-data">
        <br style="clear:both">
                    <h3 style="margin-bottom: 25px; text-align: center;">Add Product</h3>
    				<div class="form-group">
    					<label for="categories" class=" form-control-label">Categories</label>
											<select class="form-control" name="categories_id" required>
											<option value="">Select Category</option>
											<?php
											$res=mysqli_query($con,"select id,categories from categories order by categories asc");
											while($row=mysqli_fetch_assoc($res)){
												if($row['id']==$categories_id){
													echo "<option selected value=".$row['id'].">".$row['categories']."</option>";
												}else{
													echo "<option value=".$row['id'].">".$row['categories']."</option>";
												}											
											}
										?>
									</select>
					</div>
					<div class="form-group">
						<label for="categories" class=" form-control-label">Product Name</label>
						<input type="text" name="name" placeholder="Enter product name" class="form-control" required value="<?php echo $name?>">
					</div>

					<div class="form-group">
						<label for="categories" class=" form-control-label">Description</label>
						<textarea name="description" type="textarea" id="description" placeholder="Enter product description" class="form-control" maxlength="140" rows="7" required><?php echo $description?></textarea>  
                    </div>
            
					<div class="form-group">
						<label for="categories" class=" form-control-label">RRP</label>
						<input type="number" name="rrp" placeholder="Enter product RRP" class="form-control" required value="<?php echo $rrp?>">
					</div>
								
					<div class="form-group">
						<label for="categories" class=" form-control-label">Price</label>
						<input type="number" name="price" placeholder="Enter product price" class="form-control" required value="<?php echo $price?>">
					</div>
								
					<div class="form-group">
					<label for="categories" class=" form-control-label">Quantity</label>
						<input type="number" name="qty" placeholder="Enter quantity" class="form-control" required value="<?php echo $qty?>">
					</div>
					<div class="form-group">
						<label for="categories" class=" form-control-label">Tags</label>
						<input type="text" name="prokey" placeholder="Enter tag/s" class="form-control" required value="<?php echo $prokey?>">
					</div>
								
					<div class="form-group">
						<label for="categories" class=" form-control-label">Image</label>
						<input type="file" name="image" class="form-control" accept="image/jpeg, image/png" <?php echo  $image_required?>>
					</div>							
            
        		 	<button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
					    <span id="payment-button-amount">Submit</span>
					</button>
					<div class="field_error"><?php echo $msg?></div>
        </form>
    </div>
</div>
</div>

</div>

<script type="text/javascript">
	
	$(document).ready(function(){ 
    $('#characterLeft').text('140 characters left');
    $('#message').keydown(function () {
        var max = 140;
        var len = $(this).val().length;
        if (len >= max) {
            $('#characterLeft').text('You have reached the limit');
            $('#characterLeft').addClass('red');
            $('#btnSubmit').addClass('disabled');            
        } 
        else {
            var ch = max - len;
            $('#characterLeft').text(ch + ' characters left');
            $('#btnSubmit').removeClass('disabled');
            $('#characterLeft').removeClass('red');            
        }
    });    
});

</script>

<?php
        } else {

?>
<?php header('location:login.php'); ?>
<?php } ?>