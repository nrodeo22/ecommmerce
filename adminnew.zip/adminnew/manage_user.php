
<?php
    require('connection.inc.php');
    require('functions.inc.php');

if(isset($_GET['type']) && $_GET['type']!=''){
  $type=get_safe_value($con,$_GET['type']);
  if($type=='status'){
    $operation=get_safe_value($con,$_GET['operation']);
    $id=get_safe_value($con,$_GET['id']);
    if($operation=='active'){
      $status='1';
    }else{
      $status='0';
    }
    $update_status_sql="update products set status='$status' where id='$id'";
    mysqli_query($con,$update_status_sql);
  }
  
  if($type=='delete'){
    $id=get_safe_value($con,$_GET['id']);
    $delete_sql="delete from users where id='$id'";
    mysqli_query($con,$delete_sql);
  }
}

$sql="select * from users order by id desc";
$res=mysqli_query($con,$sql);
?>

<?php 

       if(!empty($_SESSION["username"])){ 
        
?>


<?php include 'includes/headers.php';?>

    <div id="wrapper">

      <!-- Sidebar -->
      <?php include 'includes/sidebar.php' ?>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Manage Users</li>
          </ol>

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              Users
            </div>

            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>ID</th>
                       <th>Userame</th>
                       <th>Email</th>
                       <th>Fullname</th>
                       <th>Image</th>
                       <th></th>
                    </tr>
                  </thead>
                  
                  <tbody>
                    <?php 
                      //$i='';
                      while($row=mysqli_fetch_assoc($res)){?>
                      <tr>
                         <!--<td class="serial"><?php echo $i?></td>-->
                         <td><?php echo $row['id']?></td>
                         <td><?php echo $row['username']?></td>
                         <td><?php echo $row['email']?></td>           
                         <td><?php echo $row['fullname']?></td>
                         <td><img src="../img/uploads/<?=$row['images']?>" style="width:3rem; height: 3rem;"/></td>
                         <td>
                        <?php
                        echo "<span class='badge badge-delete'><a href='?type=delete&id=".$row['id']."'>Delete</a></span>";
                        
                        ?>
                         </td>
                      </tr>
                      <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
          </div>

          <p class="small text-center text-muted my-5">
            <em>More table examples coming soon...</em>
          </p>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <?php include 'includes/footer.php' ?>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <?php include 'includes/logout_modal.php' ?>

    <?php include 'js/js.php' ?>

    
<?php
        } else {

?>
<?php header('location:login.php'); ?>
<?php } ?>

  </body>

</html>
