<?php
session_start();
$con=mysqli_connect("localhost","id16475034_adminnew","-r?Hz6$5Z&+><9}9","id16475034_adminpanel");
define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'../../adminnew/');
define('SITE_PATH','../../../adminnew/');

define('PRODUCT_IMAGE_SERVER_PATH',SERVER_PATH.'img/');
define('PRODUCT_IMAGE_SITE_PATH',SITE_PATH.'img/');
?>
