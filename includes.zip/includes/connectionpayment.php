<?php

$server = "localhost";
$username = "id16475034_adminnew";
$password = "-r?Hz6$5Z&+><9}9";
$database = "id16475034_adminpanel";

$con = mysqli_connect($server, $username, $password, $database);

$db = new mysqli($server, $username, $password, $database);

if ($db->connect_error) {
	die('Error : (' . $db->connect_errno . ') ' . $db->connect_error);
}
?>