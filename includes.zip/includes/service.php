<!-- Services section -->
	<section id="what-we-do">
		<div class="container-fluid">
			<h2 class="section-title mb-2 h1">OUR PROCESS</h2>
			<p class="text-center text-muted h5">Focused on effectiveness and efficiency in giving service.</p>
			<div class="row mt-5">
				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
					<div class="card">
						<div class="card-block block-1">
							<h3 class="card-title">Fast service</h3>
							<p class="card-text">With a reservation and email support for convenient and fast process.</p>
						
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
					<div class="card">
						<div class="card-block block-2">
							<h3 class="card-title">Secure payments</h3>
							<p class="card-text">Offers online or physical payment for bought products.</p>
							
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
					<div class="card">
						<div class="card-block block-3">
							<h3 class="card-title">Expert team</h3>
							<p class="card-text">Backed by experienced company, and developers to offer optimal experience.</p>
							
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
					<div class="card">
						<div class="card-block block-4">
							<h3 class="card-title">Affordable services</h3>
							<p class="card-text">Services that is being offered affordably both for customer and company's satisfaction.</p>
							
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
					<div class="card">
						<div class="card-block block-5">
							<h3 class="card-title">90 Days warranty</h3>
							<p class="card-text">Offers safety of commitment for the products being sold.</p>
							
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
					<div class="card">
						<div class="card-block block-6">
							<h3 class="card-title">Award winning</h3>
							<p class="card-text">Various achievments of the company that runs the website.</p>
							
						</div>
					</div>
				</div>
			</div>
		</div>	
	</section>
	<!-- /Services section -->