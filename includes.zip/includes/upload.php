<?php
//db conn
include 'connectionpayment.php';
if (!empty($_SESSION['id'])) {
$id = $_SESSION['id'];
$msg ="";
$css_class = "";

if(isset($_POST["upload-btn"])){
    $profileImageName = $_FILES['profileImage'];

    $profileImageName = $_FILES['profileImage']['name'];

    $target = 'img/uploads/' . $profileImageName;

   if(move_uploaded_file($_FILES['profileImage']['tmp_name'], $target)){
    $sql = "UPDATE users SET images = '$profileImageName' WHERE id='$id'";
    if(mysqli_query($db,$sql))
    {
        $msg = "Image uploaded";
        $css_class = "alert-success";
    }
    else
    {
        $msg = "failed to upload";
       $css_class = "alert-danger";
    }
    
}
}
}
    /*
$file = $_FILES['profile'];

    $fileName = $file['name'];
    $fileTmpName = $file['tmp_name'];
    $fileSize =$file['size'];
    $fileError = $file['error'];
    $fileType = $file['type']; 

    $fileExt = explode('.',$fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg', 'jpeg', 'png', 'pdf', 'gif');

    if(in_array($fileActualExt, $allowed)){
        if($fileError ===0){
             if($fileSize < 1000000){
                    $fileNameNew = "profile".$id.".".$fileActualExt;
                    $fileDestination = 'img/uploads/'.$fileNameNew;
                    move_uploaded_file($fileTmpName, $fileDestination);
                    $sql = "UPDATE profileimg SET status=0 WHERE userid='$id'";
                    $result = mysqli_query($db, $sql);
                    header("Location: account.php?uploadsuccess");
             }else{
                 echo "your file is too big!";
             }
        }else{
             echo "there was an error uploading your file!";
        }
    }else{
        echo "you cannot upload type of file!";
    }
}
*/