<?php

//require 'constants.php';

//$conn = new mysqli(Host, dbName, dbUser, dbPassword);

$host = "localhost";
$dbuser = "id16475034_adminnew";
$dbpassword = "-r?Hz6$5Z&+><9}9";
$dbname = "id16475034_adminpanel";

$conn = new mysqli($host, $dbuser, $dbpassword, $dbname);


 if ($conn->connect_error) {
 	die('Database error:' . $conn->connect_error);
 }


?>
