<?php  
define('Host', 'localhost');
define('dbUser', 'id16475034_adminnew');
define('dbPassword', '-r?Hz6$5Z&+><9}9');
define('dbName', 'id16475034_adminpanel');
?>