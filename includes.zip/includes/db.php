<?php

// holding connection parameters
$username = 'id16475034_adminnew';
$dsn = 'mysql:host=localhost; dbname=id16475034_adminpanel';
$password = '-r?Hz6$5Z&+><9}9';

try {
    //pdo class
    $db = new PDO($dsn, $username , $password);
    //setting pdo mode to exception
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //conn success
    // echo 'connection success';
} catch (PDOException $ex) {
    //err mesg
    echo 'connection failed'.$ex->getMessage();
}

/*
// holding connection parameters
$username = 'root';
$dsn = 'mysql:host=localhost; dbname=adminpanel';
$password = '';

try {
    //pdo class
    $db = new PDO($dsn, $username , $password);
    //setting pdo mode to exception
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //conn success
    // echo 'connection success';
} catch (PDOException $ex) {
    //err mesg
    echo 'connection failed'.$ex->getMessage();
}
*/
?>