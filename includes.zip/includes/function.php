<?php
    session_start();
    require_once 'connectionpayment.php';
    //require($_SERVER['DOCUMENT_ROOT'] . '/email.php');
 use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require $_SERVER['DOCUMENT_ROOT'] . '/mail/Exception.php';
require $_SERVER['DOCUMENT_ROOT'] . '/mail/PHPMailer.php';
require $_SERVER['DOCUMENT_ROOT'] . '/mail/SMTP.php';
$errors = array();
$fullname = "";
$username ="";
$email = "";

//submit datas
if (isset($_POST['signup-btn'])){
    $fullname = $_POST["fullname"];
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $passwordrepeat = $_POST["passwordrepeat"];
    $postalcode= $_POST["postalcode"];
    $phonenumber= $_POST["phonenumber"];
    $barangay= $_POST["barangay"];
    $bse= $_POST["bse"];
    $region= $_POST["region"];
    $city= $_POST["city"];

//error handling //validation
    if (empty($fullname)){
        $errors['fullname'] = "fullname required";
    }
    if (empty($username)){
        $errors['username'] = "username required";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $errors['email'] = "email is invalid";
    }
    if (empty($email)){
        $errors['email'] = "email required";
    }
    if (empty($password)) 
    {
        $errors['password'] = "password required";
    }

$uppercase = preg_match('@[A-Z]@', $password);
$lowercase = preg_match('@[a-z]@', $password);
$number    = preg_match('@[0-9]@', $password);
$specialChars = preg_match('@[^\w]@', $password);

if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
    $errors['password'] = 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
}

     if ($password !== $passwordrepeat) 
     {
        $errors['password'] = "Password do not match";
     }



    //  if (empty($phonenumber)){
    //     $errors['phonenumber'] = "phone number required";
    // }
    // if (empty($postalcode)){
    //     $errors['postalcode'] = "postal code required";
    // }
    // if (empty($city)){
    //     $errors['city'] = "city required";
    // }
    // if (empty($region)){
    //     $errors['region'] = "region required";
    // }
    // if (empty($barangay)){
    //     $errors['barangay'] = "barangay required";
    // }
    // if (empty($bse)){
    //     $errors['bse'] = "bse required";
    // }

     $emailQuery = "SELECT * FROM users WHERE email=? LIMIT 1";
     $stmt = $db->prepare($emailQuery);
     $stmt->bind_param('s', $email);
     $stmt->execute();
     $result = $stmt->get_result();
     $userCount = $result->num_rows;

     if ($userCount > 0) 
     {
         $errors['email'] = "email already exist";
     }

     if (count($errors) === 0) 
     {
         $password = password_hash($password, PASSWORD_DEFAULT);
         $token = bin2hex(random_bytes(50));
         $verified = "verified";
         $code = rand(999999, 111111);

         $sql = "INSERT INTO users(username, email, fullname, password,token, verified,code,phonenumber, postalcode, city, region, barangay, bse) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
         $stmt = $db->prepare($sql);
         $stmt->bind_param('sssssssssssss', $username, $email, $fullname, $password, $token, $verified, $code, $phonenumber, $postalcode, $city, $region, $barangay, $bse);
    
         if ($stmt->execute()) 
         {

            $subject = "Email Verification Code";
            $message = "Your verification code is $code";
            $sender = "From: thehackerist2021@gmail.com";
$mail = new PHPMailer;
$mail->isSMTP(); 
$mail->SMTPDebug = 2; // 0 = off (for production use) - 1 = client messages - 2 = client and server messages
$mail->Host = "smtp.gmail.com"; // use $mail->Host = gethostbyname('smtp.gmail.com'); // if your network does not support SMTP over IPv6
$mail->Port = 587; // TLS only
$mail->SMTPSecure = 'tls'; // ssl is deprecated
$mail->SMTPAuth = true;
$mail->Username = 'thehackerist2021@gmail.com'; // email
$mail->Password = 'th3hack3rist'; // password
$mail->setFrom('thehackerist2021@gmail.com', 'The Hackerists'); // From email and name
$mail->addAddress("$email", ''); // to email and name
$mail->Subject = 'OTP Verification for Hackerist Website';
$mail->msgHTML("$message"); //$mail->msgHTML(file_get_contents('contents.html'), __DIR__); //Read an HTML message body from an external file, convert referenced images to embedded,
$mail->AltBody = 'HTML messaging not supported'; // If html emails is not supported by the receiver, show this body
// $mail->addAttachment('images/phpmailer_mini.png'); //Attach an image file
$mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );
if(!$mail->send()){
    //echo "Mailer Error: " . $mail->ErrorInfo;
$errors['otp-error'] = "Failed while sending code!";
                header('location: index.php');
}else{
    $info = "We've sent a verification code to your email - $email";
                $_SESSION['info'] = $info;
                $_SESSION['email'] = $email;
                $_SESSION['password'] = $password;
                header('location: user-otp.php');
                exit();
}
         //   if(mail($email, $subject, $message, $sender)){
            //    $info = "We've sent a verification code to your email - $email";
            //    $_SESSION['info'] = $info;
            //    $_SESSION['email'] = $email;
             //   $_SESSION['password'] = $password;
             //   header('location: user-otp.php');
         //       exit();
          //  }else{
             //   $errors['otp-error'] = "Failed while sending code!";
               // header('location: user-otp.php');
           // }

        //      //login user
        //     $user_id = $db->insert_id;
        //     $_SESSION['id'] = $user_id;
        //     $_SESSION['fullname'] = $fullname;
        //     $_SESSION['username'] = $username;
        //     $_SESSION['email'] = $email;
        //     $_SESSION['verified'] = $verified;

        //     sendVerificationEmail($email, $token);

        //     //flash messages
        //     $_SESSION['message'] = "you are now logged in";
        //     $_SESSION['alert-class'] = "alert-success";
        //     header("location: index.php");
        //     exit();
        //  }
}
      else { echo mysqli_error();   } }
 }


 if(isset($_POST['check'])){
    $_SESSION['info'] = "";
    $otp_code = mysqli_real_escape_string($con, $_POST['otp']);
    $check_code = "SELECT * FROM users WHERE code = $otp_code";
    echo $check_code;
    $code_res = mysqli_query($con, $check_code);
    if(mysqli_num_rows($code_res) > 0){
        $fetch_data = mysqli_fetch_assoc($code_res);
        $fetch_code = $fetch_data['code'];
        $email = $fetch_data['email'];
        $fullname = $fetch_data['fullname'];
        $username = $fetch_data['username'];

        $postalcode= $fetch_data["postalcode"];
        $phonenumber= $fetch_data["phonenumber"];
        $barangay= $fetch_data["barangay"];
        $bse= $fetch_data["bse"];
        $region= $fetch_data["region"];
        $city= $fetch_data["city"];



        $user_id=$fetch_data['id'];
        $code = 0;
        $status = 'verified';
        $update_otp = "UPDATE users SET code = $code, verified = '$status' WHERE code = $fetch_code";
        $update_res = mysqli_query($con, $update_otp);
        if($update_res){
            $_SESSION['email'] = $email;
            //$user_id = $db->insert_id;
            $_SESSION['id'] = $user_id;
            $_SESSION['fullname'] = $fullname;
            $_SESSION['username'] = $username;
            $_SESSION['phonenumber'] = $phonenumber;
            $_SESSION['postalcode'] = $postalcode;
            $_SESSION['city'] = $city;
            $_SESSION['region'] = $region;
            $_SESSION['barangay'] = $barangay;
            $_SESSION['bse'] = $bse;
            $_SESSION['verified'] = $status;
            header('location: index.php');
            exit();
        }else{
            $errors['otp-error'] = "Failed while updating code!";
        }
    }else{
        $errors['otp-error'] = "You've entered incorrect code!";
    }
}








//login
if (isset($_POST['login-btn']))
{
  
    $username = $_POST["username"];
    $password = $_POST["password"];

//error handling //validation
    if (empty($username)) 
    {
        $errors['username'] = "username required";
    }
    if (empty($password)) 
    {
        $errors['password'] = "password required";
    }

    if(count($errors) === 0){

    $sql = "SELECT * FROM users WHERE email=? OR username=? LIMIT 1";
    $stmt = $db->prepare($sql);
    $stmt->bind_param('ss', $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $email = $user['email'];
    $user_id = $user['id'];
    if (password_verify($password, $user['password'])) 
    {
        $code = rand(999999, 111111);
        $sql = "UPDATE users SET code=? WHERE email = '$email'";
        $stmt = $db->prepare($sql);
        $stmt->bind_param('s', $code);
        $stmt->execute();

            
          $subject = "Email Verification Code";
          $message = "Your verification code is $code";
          $sender = "From: shahiprem7890@gmail.com";
          
          
          
          
          
          
          $mail = new PHPMailer;
$mail->isSMTP(); 
$mail->SMTPDebug = 2; // 0 = off (for production use) - 1 = client messages - 2 = client and server messages
$mail->Host = "smtp.gmail.com"; // use $mail->Host = gethostbyname('smtp.gmail.com'); // if your network does not support SMTP over IPv6
$mail->Port = 587; // TLS only
$mail->SMTPSecure = 'tls'; // ssl is deprecated
$mail->SMTPAuth = true;
$mail->Username = 'thehackerist2021@gmail.com'; // email
$mail->Password = 'th3hack3rist'; // password
$mail->setFrom('thehackerist2021@gmail.com', 'The Hackerists'); // From email and name
$mail->addAddress("$email", ''); // to email and name
$mail->Subject = 'OTP Verification for Hackerist Website';
$mail->msgHTML("$message"); //$mail->msgHTML(file_get_contents('contents.html'), __DIR__); //Read an HTML message body from an external file, convert referenced images to embedded,
$mail->AltBody = 'HTML messaging not supported'; // If html emails is not supported by the receiver, show this body
// $mail->addAttachment('images/phpmailer_mini.png'); //Attach an image file
$mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );
if(!$mail->send()){
    //echo "Mailer Error: " . $mail->ErrorInfo;
$errors['otp-error'] = "Failed while sending code!";
                header('location: index.php');
}else{
    $info = "We've sent a verification code to your email - $email";
                $_SESSION['info'] = $info;
                $_SESSION['email'] = $email;
                $_SESSION['password'] = $password;
                header('location: user-otp.php');
                exit();
}
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          if(mail($email, $subject, $message, $sender)){
              $info = "We've sent a verification code to your email - $email";
               
              $_SESSION['info'] = $info;
              $_SESSION['email'] = $email;
              $_SESSION['password'] = $password;
              $_SESSION['id'] = $userid;
              header('location: user-otp.php');
              exit();
          }  else {
              $errors['otp-error'] = "Failed while sending code!"; echo $user_id;
          }

    }
    else
    {
        $errors['otp-error'] = "Wrong Credentials!";
    }

}
}

//logout user
if(isset($_GET['logout'])){
    session_destroy();
    unset($_SESSION['id']);
    unset($_SESSION['fullname']);
    unset($_SESSION['username']);
    unset($_SESSION['email']);
    unset($_SESSION['verified']);
    header("location: index.php");
    exit();
}



if(isset($_POST['forgotpassword']))
{
    $email = $_POST['email'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
    {
        $errors['email'] = "email is invalid";
    }
    if (empty($email)) 
    {
        $errors['email'] = "email required";
    }

    if(count($errors) == 0)
    {
        $sql = "SELECT * FROM users WHERE email='$email' LIMIT 1";
        $result = mysqli_query($db, $sql);
        $user = mysqli_fetch_assoc($result);
        $token = $user['token'];
        sendPasswordResetLink($email, $token);
        header("location: password_message.php");
        exit(0);
    }
}

//if user click continue button in forgot password form
    if(isset($_POST['check-email'])){
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $check_email = "SELECT * FROM users WHERE email='$email'";
        $run_sql = mysqli_query($con, $check_email);
        if(mysqli_num_rows($run_sql) > 0){
            $code = rand(999999, 111111);
            $insert_code = "UPDATE users SET code = $code WHERE email = '$email'";
            $run_query =  mysqli_query($con, $insert_code);
            if($run_query){
                $subject = "Password Reset Code";
                $message = "Your password reset code is $code";
                $sender = "From: thehackerist2021@gmail.com";

                $mail = new PHPMailer;
$mail->isSMTP(); 
$mail->SMTPDebug = 2; // 0 = off (for production use) - 1 = client messages - 2 = client and server messages
$mail->Host = "smtp.gmail.com"; // use $mail->Host = gethostbyname('smtp.gmail.com'); // if your network does not support SMTP over IPv6
$mail->Port = 587; // TLS only
$mail->SMTPSecure = 'tls'; // ssl is deprecated
$mail->SMTPAuth = true;
$mail->Username = 'thehackerist2021@gmail.com'; // email
$mail->Password = 'th3hack3rist'; // password
$mail->setFrom('thehackerist2021@gmail.com', 'The Hackerists'); // From email and name
$mail->addAddress("$email", ''); // to email and name
$mail->Subject = 'Password Reset Code';
$mail->msgHTML("$message"); //$mail->msgHTML(file_get_contents('contents.html'), DIR); //Read an HTML message body from an external file, convert referenced images to embedded,
$mail->AltBody = 'HTML messaging not supported'; // If html emails is not supported by the receiver, show this body
// $mail->addAttachment('images/phpmailer_mini.png'); //Attach an image file
$mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );
if(!$mail->send()){
    //echo "Mailer Error: " . $mail->ErrorInfo;
$errors['otp-error'] = "Failed while sending code!";
                header('location: index.php');
}else{
   $info = "We've sent a passwrod reset otp to your email - $email";
                    $_SESSION['info'] = $info;
                    $_SESSION['email'] = $email;
                    header('location: reset-code.php');
                    exit();
}
      
            }else{
                $errors['db-error'] = "Something went wrong!";
            }
        }else{
            $errors['email'] = "This email address does not exist!";
        }
    }

    //if user click check reset otp button
    if(isset($_POST['check-reset-otp'])){
        $_SESSION['info'] = "";
        $otp_code = mysqli_real_escape_string($con, $_POST['otp']);
        $check_code = "SELECT * FROM users WHERE code = $otp_code";
        $code_res = mysqli_query($con, $check_code);
        if(mysqli_num_rows($code_res) > 0){
            $fetch_data = mysqli_fetch_assoc($code_res);
            $email = $fetch_data['email'];
            $_SESSION['email'] = $email;
            $info = "Please create a new password that you don't use on any other site.";
            $_SESSION['info'] = $info;
            header('location: new-password.php');
            exit();
        }else{
            $errors['otp-error'] = "You've entered incorrect code!";
        }
    }

    //if user click change password button
    if(isset($_POST['change-password'])){
        $_SESSION['info'] = "";
        $password = mysqli_real_escape_string($con, $_POST['password']);
        $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);
        if($password !== $cpassword){
            $errors['password'] = "Confirm password not matched!";
        }else{
            $code = 0;
            $email = $_SESSION['email']; //getting this email using session
            $encpass = password_hash($password, PASSWORD_BCRYPT);
            $update_pass = "UPDATE users SET code = $code, password = '$encpass' WHERE email = '$email'";
            $run_query = mysqli_query($con, $update_pass);
            if($run_query){
                $info = "Your password changed. Now you can login with your new password.";
                $_SESSION['info'] = $info;
                header('Location: password-changed.php');
            }else{
                $errors['db-error'] = "Failed to change your password!";
            }
        }
    }
    
   //if login now button click
    if(isset($_POST['login-now'])){
        header('Location: login.php');
    }

if(isset($_POST['update-btn']))
{
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $email= $_SESSION['email'];
    $phonenumber = $_POST['phonenumber'];
    //$gender = $_POST['gender'];
    $postalcode = $_POST['postalcode'];
    $region = $_POST['region'];
    $city = $_POST['city'];
    $barangay = $_POST['barangay'];
    $bse = $_POST['bse'];
    $sql = "SELECT * FROM users WHERE email='$email' LIMIT 1";
    $result = mysqli_query($db, $sql);

    if(mysqli_num_rows($result) > 0)
    {
        $user = mysqli_fetch_assoc($result);
        $update_query = "UPDATE users SET fullname='$fullname', username='$username', phonenumber='$phonenumber', postalcode='$postalcode', barangay='$barangay', region='$region', city='$city', bse='$bse' WHERE email='$email' ";

        if(mysqli_query($db, $update_query))
        {
            //login user
            //login success
            $_SESSION['fullname'] = $fullname;
            $_SESSION['username'] = $username;
            $_SESSION['phonenumber'] = $phonenumber;
            $_SESSION['gender'] = $gender;
            $_SESSION['postalcode'] = $postalcode;
            $_SESSION['region'] = $region;
            $_SESSION['city'] = $city;
            $_SESSION['barangay'] = $barangay;
            $_SESSION['bse'] = $bse;
            
            $_SESSION['verified'] = $status;
            //flash messages
            $_SESSION['message'] = "profile update sucessful!!";
            $_SESSION['alert-class'] = "alert-success";
            header("location: account.php");
            exit();
        }
    }
    else
    {
        echo 'user not found';
    }
}








