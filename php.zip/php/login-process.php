<?php
	session_start();
	$host 		= "localhost";
	$username 	= "id16475034_adminnew";
	$password 	= "-r?Hz6$5Z&+><9}9";
	$database 	= "id16475034_adminpanel";

	try{
		$connect = new PDO("mysql:host=$host;dbname=$database", $username, $password);
		$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		if(isset($_POST["signin-button"])){
			$username = $_POST['username'];
			$password = hash('sha256',$_POST['password']);
			// $password = $_POST['password'];

			/*if($username == 'admin'){
				$_SESSION["username"] = $username;
				header("Location:../index.php");
			}*/
	
			if(empty($username) || empty($password)){
				header("Location:../login.php?error=emptyFields");
				exit();
			} else {
				$query = "SELECT * FROM admin WHERE username = :username AND password = :password";
				$statement = $connect->prepare($query);
				$statement->execute(
					array(
						'username' => $username,
						'password' => $password
					)
				);

				$count = $statement->rowCount();
				
				$query2 = "SELECT * FROM users WHERE username = :username AND password = :password";
				$statement2 = $connect->prepare($query2);
				$statement2->execute(
					array(
						'username' => $username,
						'password' => $password
					)
				);

				
				$count2 = $statement2->rowCount();

				if($count > 0 && $username == 'admin'){
					$_SESSION["username"] = $username;
					header("Location:../index.php");
					echo 'hit';

				} 
				else if($count2 > 0){
					$_SESSION["username"] = $username;
					$query = "SELECT * FROM users WHERE username = :username";
					$statement = $connect->prepare($query);
					$statement->execute(
						array(
							'username' => $username
						)
					);
					while($row=$statement->fetch()){ //for each result, do the following
			     		$id 			= $row['id'];
			     		$firstname		= $row['firstname'];
			     		$lastname 		= $row['lastname'];
			     		$username 		= $row['username'];
			     		$phoneNumber 	= $row['phonenumber'];
			     		$email			= $row['email'];
			     		$verification	= $row['verification'];
			     		$dateCreated	= $row['datecreated'];
			    		//do something with the variables
					}
					$_SESSION["id"] 			= $id;
		     		$_SESSION["firstname"] 		= $firstname;
		     		$_SESSION["lastname"] 		= $lastname;
		     		$_SESSION["username"] 		= $username;
		     		$_SESSION["phonenumber"] 	= $phoneNumber;
		     		$_SESSION["email"] 			= $email;
		     		$_SESSION["verification"] 	= $verification;
		     		$_SESSION["datecreated"] 	= $dateCreated;

					header("Location:../index.php");
				} 
				else {
					header("Location:../login.php?error=invalidUsernameOrPassword");
				}
			}
		}
	}
	catch(PDOException $error){
		$message = $error->getMessage();
	}
?>
