<?php
	session_start();
	$host 		= "localhost";
	$username 	= "root";
	$password 	= "";
	$database 	= "test";
	$message    = "";

	try{
		$connect = new PDO("mysql:host=$host;dbname=$database", $username, $password);
		$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		if(isset($_POST["signup-button"])){
			
			$firstname		= $_POST['fname'];
			$lastname		= $_POST['lname'];
			$email 			= $_POST['email'];
			$phoneNumber	= $_POST['phonenumber'];
			$username 		= $_POST['username'];		
			$password 		= hash('sha256',$_POST['password']);
			$passwordRepeat = hash('sha256',$_POST['rpassword']);
			$verification   = "unverified";

			if(empty($firstname) || empty($username) || empty($email) || empty($password) || empty($phoneNumber) || empty($passwordRepeat) || empty($lastname)){
				$message = '<label>All fields are required.</label>';
				// $_SESSION['message'] = $message;
				header("Location:../registration.php?error=emptyFields");
				exit();
			}
			else if(!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/", $username)){

				$message = '<label>All fields are required.</label>';
				header("Location:../registration.php?error=invalidUsername&Email");
				exit();
			}
			else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){

				$message = '<label>Invalid Email</label>';
				header("Location:../registration.php?error=invalidEmail");
				exit();
			}
			else if (!preg_match("/^[a-zA-Z0-9]*$/", $username)) {

				$message = '<label>Invalid Username</label>';
				header("Location:../registration.php?error=invalidUsername");
				exit();
			}
			else if($password < 6){
				header("Location:../registration.php?error=passwordIsTooShort");
				exit();
			}
			else if($password !== $passwordRepeat){

				$message = '<label>Invalid Password</label>';
				header("Location:../registration.php?error=checkPassword");
				exit();
			}
			else{
				$query = "SELECT COUNT(*) AS num FROM `users` WHERE username = ?";
				$statement = $connect->prepare($query);
				$result = $statement->execute([$username]);
				$row = $statement->fetch(PDO::FETCH_ASSOC);

				$query2 = "SELECT COUNT(*) AS num FROM `users` WHERE email = ?";
				$statement2 = $connect->prepare($query2);
				$result2 = $statement2->execute([$email]);
				$row2 = $statement2->fetch(PDO::FETCH_ASSOC);
				
				if($row['num'] > 0 && $row2['num'] > 0){
					header("Location:../registration.php?error=username&EmailAlreadyTaken");
					exit();
				}
				if($row['num'] > 0){
					//$message = '<label>Username Taken</label>';
					header("Location:../registration.php?error=usernameAlreadyTaken");
					exit();
				}
				if($row2['num'] > 0){
					header("Location:../registration.php?error=emailAlreadyTaken");
					exit();
				} 
				else { 
					$query = "INSERT INTO users (firstname, lastname, email, phonenumber, username, password, verification) VALUES (:firstname, :lastname, :email, :phonenumber, :username, :password, :verification)";
					$statement = $connect->prepare($query);
					$result = $statement->execute(
						array(
							'firstname'    	=> $firstname,
							'lastname'    	=> $lastname,
							'email' 	  	=> $email,
							'phonenumber' 	=> $phoneNumber,
							'username' 	  	=> $username,
							'password'    	=> $password,
							'verification'	=> $verification
						)
					);
					if($result){
						header("Location:../registration.php?success");
						echo "hit";
					}
					else{
						echo "error";
					}
				}
			} 		
		}		
	}
	catch(PDOException $error){
		$message = $error->getMessage();
	}
?>
